from urllib import request
from bs4 import BeautifulSoup

#url에 접속
html=urllib.request.urlopen("  ")

#Beautiful을 이용하여 다루기 쉬운형태로 변형
soup=BeautifulSoup(html, "lxml")

#추출하고자 하는 부분의 태그와 속성, 속성값 찾아서 가져오기 
nameList = soup.find_all('span')
for name in nameList:
    print(name.get_text())
