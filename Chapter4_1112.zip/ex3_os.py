import os

print("운영체제 ", os.name)
print("폴더 ", os.getcwd())
print("현재 폴더의 내용", os.listdir())
os.mkdir("hello")
os.rmdir("hello")

