import datetime
print("현재시각")
now = datetime.datetime.now()
print(now.year)
print(now.month)
print(now.day)
print(now.hour)
print()

output = now.strftime("%Y.%m.%d %H:%M:%S")
print(output)

# 특정 시간 이후의 시간

print(output)

## 1년 후 

print(output)
