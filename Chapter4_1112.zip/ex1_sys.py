import sys
try:
    n = int(sys.argv[1])
except:
    sys.exit('실행 명 다음에 숫자를 넣으세요')
print(n**2)