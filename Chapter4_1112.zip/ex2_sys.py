import sys
print(sys.argv)
print("---------------")
print("getwindowsversion()", sys.getwindowsversion())
print("---------------")
print("copyrigth:", sys.copyright)
print("---------------")
print("version:", sys.version)
sys.exit()